package com.mycompany.cadastrodevinhos;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Gustavo
 */
public class CadastroVinhos extends javax.swing.JFrame {

    private ArrayList<Vinho> listaVinhos = new ArrayList<>();

    //Variáveis sobre envelhecimento
    String carvalhoFrances = "não";
    String carvalhoAmericano = "não";
    String inox = "não";
    String emGarrafa = "não";

    //Variável sobre gênero
    String vitis = "";

    public CadastroVinhos() {
        initComponents();
        generoVitis.add(rbtVinifera);
        generoVitis.add(rbtLabrusca);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        generoVitis = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtProd = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        cmbClass = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        txtDOC = new javax.swing.JTextField();
        rbtVinifera = new javax.swing.JRadioButton();
        rbtLabrusca = new javax.swing.JRadioButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtUvaPred = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        spnPot = new javax.swing.JSpinner();
        btnCadastrar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        spnSafra = new javax.swing.JSpinner();
        jLabel12 = new javax.swing.JLabel();
        cmbTipo = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        cmbCor = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        spnMeses = new javax.swing.JSpinner();
        cheCarvalhoFranc = new javax.swing.JCheckBox();
        cheCarvalhoAmer = new javax.swing.JCheckBox();
        cheInox = new javax.swing.JCheckBox();
        cheGarrafa = new javax.swing.JCheckBox();
        jLabel16 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        menuArquivo = new javax.swing.JMenu();
        menuCadastrar = new javax.swing.JMenuItem();
        menuConsultar = new javax.swing.JMenuItem();
        menuSair = new javax.swing.JMenu();
        menuFechar = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cadastro de Vinhos");
        setUndecorated(true);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Gustavo\\Downloads\\Image.png")); // NOI18N

        jLabel2.setText("Cod");

        jLabel3.setText("xxx");

        jLabel4.setText("Nome (rótulo)");

        jLabel5.setText("Produtor");

        jLabel6.setText("Classificação");

        cmbClass.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Suave", "Seco", "Demi-Sec" }));
        cmbClass.setName(""); // NOI18N

        jLabel7.setText("D.O.C");

        generoVitis.add(rbtVinifera);
        rbtVinifera.setText("Vinífera");
        rbtVinifera.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtViniferaActionPerformed(evt);
            }
        });

        generoVitis.add(rbtLabrusca);
        rbtLabrusca.setText("Labrusca");
        rbtLabrusca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtLabruscaActionPerformed(evt);
            }
        });

        jLabel8.setText("Gênero Vitis");

        jLabel9.setText("Uva Predominante");

        jLabel10.setText("Potencial de Guarda");

        btnCadastrar.setText("Cadastrar");
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        jLabel11.setText("Safra");

        jLabel12.setText("Tipo");

        cmbTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Espumante", "Frisante", "Vinho", "Vinho Licoroso" }));

        jLabel13.setText("Cor");

        cmbCor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Branco", "Tinto", "Rose" }));

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        jLabel14.setText("Envelhecimento");

        jLabel15.setText("Tempo em Meses");

        cheCarvalhoFranc.setText("Carvalho Francês");
        cheCarvalhoFranc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cheCarvalhoFrancActionPerformed(evt);
            }
        });

        cheCarvalhoAmer.setText("Carvalho Americano");
        cheCarvalhoAmer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cheCarvalhoAmerActionPerformed(evt);
            }
        });

        cheInox.setText("Inox");
        cheInox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cheInoxActionPerformed(evt);
            }
        });

        cheGarrafa.setText("Em Garrafa");
        cheGarrafa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cheGarrafaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cheCarvalhoFranc)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(cheCarvalhoAmer)
                                        .addComponent(cheInox, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(cheGarrafa, javax.swing.GroupLayout.Alignment.LEADING)))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel15)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, Short.MAX_VALUE)
                                .addComponent(spnMeses, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(19, 19, 19))))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel14)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(spnMeses, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(cheCarvalhoFranc)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cheCarvalhoAmer)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cheInox)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cheGarrafa)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jLabel16.setText("anos");

        menuArquivo.setText("Arquivo");

        menuCadastrar.setText("Cadastrar");
        menuArquivo.add(menuCadastrar);

        menuConsultar.setText("Consultar");
        menuConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuConsultarActionPerformed(evt);
            }
        });
        menuArquivo.add(menuConsultar);

        jMenuBar1.add(menuArquivo);

        menuSair.setText("Sair");

        menuFechar.setText("Fechar");
        menuFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuFecharActionPerformed(evt);
            }
        });
        menuSair.add(menuFechar);

        jMenuBar1.add(menuSair);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtDOC, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cmbClass, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel3)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtNome)
                        .addGap(52, 52, 52)
                        .addComponent(jLabel11)
                        .addGap(18, 18, 18)
                        .addComponent(spnSafra, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(jLabel12)
                        .addGap(18, 18, 18)
                        .addComponent(cmbTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(59, 59, 59))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(txtProd, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel13)
                        .addGap(25, 25, 25)
                        .addComponent(cmbCor, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(257, 257, 257))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addGap(36, 36, 36)
                                .addComponent(txtUvaPred, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(86, 86, 86)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(rbtLabrusca)
                                    .addComponent(rbtVinifera)))
                            .addComponent(jLabel8)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addGap(18, 18, 18)
                                .addComponent(spnPot, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel16))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnCadastrar)
                                .addGap(18, 18, 18)
                                .addComponent(btnCancelar)))))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(spnSafra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(cmbTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtProd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(cmbCor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(cmbClass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txtDOC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(rbtVinifera)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rbtLabrusca)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(txtUvaPred, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(spnPot, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16)))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCadastrar)
                    .addComponent(btnCancelar))
                .addGap(0, 22, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void menuFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuFecharActionPerformed
        this.dispose();
    }//GEN-LAST:event_menuFecharActionPerformed

    private void rbtViniferaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtViniferaActionPerformed
        if (rbtVinifera.isSelected()) {
            vitis = "Vinífera";
        }
    }//GEN-LAST:event_rbtViniferaActionPerformed

    private void rbtLabruscaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtLabruscaActionPerformed
        if (rbtLabrusca.isSelected()) {
            vitis = "Labrusca";
        }
    }//GEN-LAST:event_rbtLabruscaActionPerformed

    private void cheCarvalhoFrancActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cheCarvalhoFrancActionPerformed

    }//GEN-LAST:event_cheCarvalhoFrancActionPerformed

    private void cheCarvalhoAmerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cheCarvalhoAmerActionPerformed

    }//GEN-LAST:event_cheCarvalhoAmerActionPerformed

    private void cheInoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cheInoxActionPerformed

    }//GEN-LAST:event_cheInoxActionPerformed

    private void cheGarrafaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cheGarrafaActionPerformed

    }//GEN-LAST:event_cheGarrafaActionPerformed

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
        if (txtNome.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, preencha o nome do vinho.", "Campo obrigatório", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String corSelecionada = cmbCor.getSelectedItem().toString();
        String clasSelecionada = cmbClass.getSelectedItem().toString();
        Vinho vinho = new Vinho(
                txtNome.getText(),
                txtProd.getText(),
                txtDOC.getText(),
                clasSelecionada,
                corSelecionada,
                cheCarvalhoFranc.isSelected() ? "Sim" : "Não",
                cheCarvalhoAmer.isSelected() ? "Sim" : "Não",
                cheInox.isSelected() ? "Sim" : "Não",
                cheGarrafa.isSelected() ? "Sim" : "Não",
                vitis,
                txtUvaPred.getText(),
                cmbTipo.getSelectedItem().toString(),
                (int) spnPot.getValue(),
                (int) spnSafra.getValue(),
                (int) spnMeses.getValue()
        );
        listaVinhos.add(vinho);
        JOptionPane.showMessageDialog(this, "Vinho cadastrado com sucesso!");
        limparCampos();
    }//GEN-LAST:event_btnCadastrarActionPerformed

    private void menuConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuConsultarActionPerformed
        if (!listaVinhos.isEmpty()) {
            Consulta consulta = new Consulta(listaVinhos);
            consulta.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "A lista está vazia!");
        }
    }//GEN-LAST:event_menuConsultarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        limparCampos();
    }//GEN-LAST:event_btnCancelarActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroVinhos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JCheckBox cheCarvalhoAmer;
    private javax.swing.JCheckBox cheCarvalhoFranc;
    private javax.swing.JCheckBox cheGarrafa;
    private javax.swing.JCheckBox cheInox;
    private javax.swing.JComboBox<String> cmbClass;
    private javax.swing.JComboBox<String> cmbCor;
    private javax.swing.JComboBox<String> cmbTipo;
    private javax.swing.ButtonGroup generoVitis;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JMenu menuArquivo;
    private javax.swing.JMenuItem menuCadastrar;
    private javax.swing.JMenuItem menuConsultar;
    private javax.swing.JMenuItem menuFechar;
    private javax.swing.JMenu menuSair;
    private javax.swing.JRadioButton rbtLabrusca;
    private javax.swing.JRadioButton rbtVinifera;
    private javax.swing.JSpinner spnMeses;
    private javax.swing.JSpinner spnPot;
    private javax.swing.JSpinner spnSafra;
    private javax.swing.JTextField txtDOC;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtProd;
    private javax.swing.JTextField txtUvaPred;
    // End of variables declaration//GEN-END:variables

    private void limparCampos() {
        // Limpar campos de texto
        txtNome.setText("");
        txtProd.setText("");
        txtDOC.setText("");
        txtUvaPred.setText("");

        // Limpar comboboxes
        cmbClass.setSelectedIndex(0); // Selecionar o primeiro item
        cmbCor.setSelectedIndex(0);
        cmbTipo.setSelectedIndex(0);

        // Limpar spinners
        spnPot.setValue(0);
        spnSafra.setValue(0);
        spnMeses.setValue(0);

        // Limpar checkboxes
        cheCarvalhoFranc.setSelected(false);
        cheCarvalhoAmer.setSelected(false);
        cheInox.setSelected(false);
        cheGarrafa.setSelected(false);

        // Limpar botões de radio
        generoVitis.clearSelection();
    }
}
