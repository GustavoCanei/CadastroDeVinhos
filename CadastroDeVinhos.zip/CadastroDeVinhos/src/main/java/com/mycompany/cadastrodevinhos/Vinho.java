package com.mycompany.cadastrodevinhos;

public class Vinho {
    private String nome;
    private String produtor;
    private String doc;
    private String classificacao;
    private String cor;
    private String carvalhoFrances;
    private String carvalhoAmericano;
    private String inox;
    private String emGarrafa;
    private String generoVitis;
    private String uvaPredominante;
    private String tipo;
    private int potencialGuarda;
    private int safra;
    private int tempoEnvelhecimento;

    public Vinho(String nome, String produtor, String doc, String classificacao, String cor, String carvalhoFrances, String carvalhoAmericano, String inox, String emGarrafa, String generoVitis, String uvaPredominante, String tipo, int potencialGuarda, int safra, int tempoEnvelhecimento) {
        this.nome = nome;
        this.produtor = produtor;
        this.doc = doc;
        this.classificacao = classificacao;
        this.cor = cor;
        this.carvalhoFrances = carvalhoFrances;
        this.carvalhoAmericano = carvalhoAmericano;
        this.inox = inox;
        this.emGarrafa = emGarrafa;
        this.generoVitis = generoVitis;
        this.uvaPredominante = uvaPredominante;
        this.potencialGuarda = potencialGuarda;
        this.safra = safra;
        this.tempoEnvelhecimento = tempoEnvelhecimento;
        this.tipo = tipo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String cod) {
        this.nome = cod;
    }

    public String getProdutor() {
        return produtor;
    }

    public void setProdutor(String produtor) {
        this.produtor = produtor;
    }

    public String getDoc() {
        return doc;
    }

    public void setDoc(String doc) {
        this.doc = doc;
    }

    public String getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(String classificacao) {
        this.classificacao = classificacao;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getCarvalhoFrances() {
        return carvalhoFrances;
    }

    public void setCarvalhoFrances(String carvalhoFrances) {
        this.carvalhoFrances = carvalhoFrances;
    }

    public String getCarvalhoAmericano() {
        return carvalhoAmericano;
    }

    public void setCarvalhoAmericano(String carvalhoAmericano) {
        this.carvalhoAmericano = carvalhoAmericano;
    }

    public String getInox() {
        return inox;
    }

    public void setInox(String inox) {
        this.inox = inox;
    }

    public String getEmGarrafa() {
        return emGarrafa;
    }

    public void setEmGarrafa(String emGarrafa) {
        this.emGarrafa = emGarrafa;
    }

    public String getGeneroVitis() {
        return generoVitis;
    }

    public void setGeneroVitis(String generoVitis) {
        this.generoVitis = generoVitis;
    }

    public String getUvaPredominante() {
        return uvaPredominante;
    }

    public void setUvaPredominante(String uvaPredominante) {
        this.uvaPredominante = uvaPredominante;
    }

    public int getPotencialGuarda() {
        return potencialGuarda;
    }

    public void setPotencialGuarda(int potencialGuarda) {
        this.potencialGuarda = potencialGuarda;
    }

    public int getSafra() {
        return safra;
    }

    public void setSafra(int safra) {
        this.safra = safra;
    }

    public int getTempoEnvelhecimento() {
        return tempoEnvelhecimento;
    }

    public void setTempoEnvelhecimento(int tempoEnvelhecimento) {
        this.tempoEnvelhecimento = tempoEnvelhecimento;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}

    
    

    
